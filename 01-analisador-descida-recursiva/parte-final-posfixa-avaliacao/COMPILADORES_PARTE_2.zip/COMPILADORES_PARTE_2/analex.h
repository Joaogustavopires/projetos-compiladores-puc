#ifndef ANALEX_H
#define ANALEX_H

#include <stdio.h>
#include <stdlib.h>

//Defini��o dos Tokens
#define NUM 257
#define ID  258

//Vari�veis Globais
extern int linha;
extern char lexema[30];

//Prot�tipos
void erro_lexico();
int analex(char* input_string, int* pos); //Recebe a string de entrada

#endif
