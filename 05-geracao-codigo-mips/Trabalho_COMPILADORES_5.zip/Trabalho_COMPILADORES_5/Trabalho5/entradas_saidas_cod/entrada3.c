int soma(int x, int y) {
	int z;
	z = x + y;
	return z;
}

int sub(int x, int y) {
	int z;
	z = x - y;
	return z;
}

int main() {
	int a, b;
	b = 10;
	a = 33 - b;
	soma(a,b);
}
