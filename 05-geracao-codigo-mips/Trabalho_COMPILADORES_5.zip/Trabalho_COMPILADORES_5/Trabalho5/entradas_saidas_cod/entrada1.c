int main() {
	int a;
	float b;
	a = 10;
	b = a - 3.0;
}
