int main() {
	int aux,cont,a, teste;
	a = 10 + 2.3;
	aux = a;
	
	if (1) 
	  teste = 0;
    endif
	  
	if (0)
	  a = a + 1;
	else
	  a = a - 1;
	endif
}
