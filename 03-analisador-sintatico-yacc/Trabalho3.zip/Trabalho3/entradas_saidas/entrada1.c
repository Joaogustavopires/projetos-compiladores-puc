int main() {
	int aux,cont,a;
	a = 10;
	aux = a;
	
	if (1) 
	  teste = 0;
    endif
	  
	if (0)
	  a = a + 1;
	else
	  a = a - 1;
	endif
}
